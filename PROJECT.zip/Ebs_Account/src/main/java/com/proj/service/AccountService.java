package com.proj.service;
import org.springframework.beans.factory.annotation.Autowired;
//
//import org.springframework.stereotype.Service;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//@Service
//public class AccountService {
//   private Map<Integer, List<Account>> accountsByCustomerId = new HashMap<>();
//   private int nextId = 1;
//   public void createAccount(AccountDTO accountDTO) {
//       Account account = new Account();
//       account.setId(nextId++);
//       account.setCustomerId(accountDTO.getCustomerId());
//       account.setAccountType(accountDTO.getAccountType());
//       account.setBalance(accountDTO.getBalance());
//       int customerId = accountDTO.getCustomerId();
//       if (!accountsByCustomerId.containsKey(customerId)) {
//           accountsByCustomerId.put(customerId, new ArrayList<>());
//       }
//       accountsByCustomerId.get(customerId).add(account);
//   }
//   public Account getAccountById(int id) {
//       for (List<Account> accounts : accountsByCustomerId.values()) {
//           for (Account account : accounts) {
//               if (account.getId() == id) {
//                   return account;
//               }
//           }
//       }
//       return null;
//   }
//   public List<Account> getAccountsByCustomerId(int customerId) {
//       return accountsByCustomerId.getOrDefault(customerId, new ArrayList<>());
//   }
//}
import org.springframework.stereotype.Service;

import com.proj.entity.Account;
import com.proj.entity.AccountDTO;
import com.proj.repository.AccountRepository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
@Service
public class AccountService {
	@Autowired
	private AccountRepository accountRepository;
	
	
	public Account createAccount(Account account) {
		return accountRepository.save(account);
	}
	
	public void updateAccount(Integer id, double balance) {
		Account account =accountRepository.FindByAccNo(id);
		account.setBalance(balance);
		accountRepository.save(account);
		
	}
//   private Map<Integer, List<Account>> accountsByCustomerId = new HashMap<>();
//   private int nextId = 1;
//   public void createAccount(AccountDTO accountDTO) {
//       Account account = new Account();
//       account.setId(nextId++);
//       account.setCustomerId(accountDTO.getCustomerId());
//       account.setAccountType(accountDTO.getAccountType());
//       account.setBalance(accountDTO.getBalance());
//       int customerId = accountDTO.getCustomerId();
//       if (!accountsByCustomerId.containsKey(customerId)) {
//           accountsByCustomerId.put(customerId, new ArrayList<>());
//       }
//       accountsByCustomerId.get(customerId).add(account);
//   }
	public Account findByAccountId(Integer id) {
		return accountRepository.getById(id);
	}
	public List<Account> getAccountsByCustomerId(Integer customerId) {
      return accountRepository.findByCustomerId(customerId);
  }
//   public Account getAccountById(int id) {
//       for (List<Account> accounts : accountsByCustomerId.values()) {
//           for (Account account : accounts) {
//               if (account.getId() == id) {
//                   return account;
//               }
//           }
//       }
//       return null;
//   }
//   public List<Account> getAccountsByCustomerId(int customerId) {
//       return accountsByCustomerId.getOrDefault(customerId, new ArrayList<>());
//   }
}