package com.proj.controller;


import java.util.List;
import java.util.Optional;

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import com.proj.service.AccountService;
//
//import java.util.List;
//@RestController
//@RequestMapping("/accounts")
//public class AccountController {
//   @Autowired
//   private AccountService accountService;
//   @PostMapping
//   public ResponseEntity<String> createAccount(@RequestBody AccountDTO accountDTO) {
//       accountService.createAccount(accountDTO);
//       return ResponseEntity.status(HttpStatus.CREATED).body("Account created successfully");
//   }
//   @GetMapping("/{id}")
//   public ResponseEntity<Account> getAccountById(@PathVariable("id") int id) {
//       Account account = accountService.getAccountById(id);
//       if (account != null) {
//           return ResponseEntity.ok(account);
//       } else {
//           return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
//       }
//   }
//   @GetMapping("/customer/{customerId}")
//   public ResponseEntity<List<Account>> getAccountsByCustomerId(@PathVariable("customerId") int customerId) {
//       List<Account> accounts = accountService.getAccountsByCustomerId(customerId);
//       return ResponseEntity.ok(accounts);
//   }
//}
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.proj.entity.Account;
import com.proj.service.AccountService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;
import lombok.extern.slf4j.Slf4j;
@RestController
@RequestMapping("/accounts")
@CrossOrigin
@Slf4j
public class AccountController {
   @Autowired
   private AccountService accountService;
   
   @PostMapping()
   public String createAcc(@RequestBody Account account){
	   //log.info("In Service : {}", account);
		accountService.createAccount(account);
		return "Your Record is Saved : ";
	   
   }
   @GetMapping("/accdetails/{id}")
	public Optional<Account> getByAccNo(@PathVariable("id") Integer id) {
		if(accountService.findByAccountId(id) != null) {
			
			return Optional.of(accountService.findByAccountId(id)); // id available
		}
		return Optional.empty(); // id not available
	}
   @PutMapping("/update/{custId}/id")
   @Consume
//   public ResponseEntity<String> createAccount(@RequestBody AccountDTO accountDTO) {
//      // accountService.createAccount(accountDTO);
//       return ResponseEntity.status(HttpStatus.CREATED).body("Account created successfully");
//   }
//   @GetMapping("/{id}")
//   public ResponseEntity<Account> getAccountById(@PathVariable("id") int id) {
//       Account account = accountService.getAccountById(id);
//       if (account != null) {
//           return ResponseEntity.ok(account);
//       } else {
//           return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
//       }
//   }
   @GetMapping("/allaccount/{customerId}")
   public ResponseEntity<List<Account>> getAccountsByCustomerId(@PathVariable("customerId") Integer customerId) {
       List<Account> accounts = accountService.getAccountsByCustomerId(customerId);
       return ResponseEntity.ok(accounts);
   }
}