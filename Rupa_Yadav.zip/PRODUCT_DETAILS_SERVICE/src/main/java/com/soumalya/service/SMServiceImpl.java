package com.soumalya.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.soumalya.entities.SMEntity;

import com.soumalya.repository.SMRepository;


@Service
public class SMServiceImpl implements SMService{
	
	@Autowired
	private SMRepository smRepository;

	@Override
	public SMEntity create(SMEntity smEntity) {
		return smRepository.save(smEntity);
	}

	@Override
	public Optional<SMEntity> getOne(Integer id) {
		return smRepository.findById(id);
	}

	@Override
	public Optional<SMEntity> getByType(String type) {
		// TODO Auto-generated method stub
		return smRepository.findByType(type);
	}

//	@Override
//	public StudentSMEntity create(StudentSMEntity ) {
//		return departmentRepository.save(departmentEntity);
//	}
//
//	@Override
//	public DepartmentEntity getOne(Integer deptId) {
//		return departmentRepository.findById(deptId).orElseThrow(()-> new RuntimeException("No Department found with id "+ deptId));
//	}
//
//	@Override
//	public List<DepartmentEntity> getAll() {
//		return departmentRepository.findAll();
//	}

}
