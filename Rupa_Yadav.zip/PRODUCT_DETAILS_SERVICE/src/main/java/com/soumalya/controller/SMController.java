`package com.soumalya.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.soumalya.entities.SMEntity;
import com.soumalya.service.SMService;





@RestController
@RequestMapping("/product")
@CrossOrigin
public class SMController {

	@Autowired
	private SMService smService;

	@GetMapping("/byid/{id}")
	public Optional<SMEntity> getById(@PathVariable Integer id) {
		return smService.getOne(id);
	}
	
	@GetMapping("/bytype/{lname}")
	public Optional<SMEntity> getByType(@PathVariable String type){
		return smService.getByType(type);
	}
	
	@PostMapping
	public SMEntity createSM(@RequestBody SMEntity smEntity) {
		return smService.create(smEntity);
	}

}
